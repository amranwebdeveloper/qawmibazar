<?php
namespace Modules\Booking\Models;

use App\BaseModel;

class BookingTimeSlots extends BaseModel
{
    protected $table      = 'bc_booking_time_slots';
}
