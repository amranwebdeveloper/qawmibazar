@extends('layouts.app')
@section('content')
    <div class="bc-booking-page padding-content" >
        <div class="container">
            <div id="bc-checkout-page" >
                <div class="row">
                    <div class="col-md-8">
                        @include('admin.message')
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
