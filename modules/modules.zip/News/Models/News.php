<?php

namespace Modules\News\Models;

use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;
use Modules\Booking\Models\Bookable;
use Modules\Core\Models\SEO;
use Modules\Review\Models\Review;

class News extends Bookable
{
    use SoftDeletes;
    protected $table = 'bc_news';
    protected $fillable = [
        'title',
        'content',
        'status',
        'cat_id',
        'property_id',
        'location_id',
        'image_id',
        'banner_image_id'
    ];
    protected $slugField     = 'slug';
    protected $slugFromField = 'title';
    protected $seo_type = 'news';
    public $type = 'news';
    public $item_loop_list = 'News::frontend.layouts.details.news-list';

    protected $sitemap_type = 'page';

    public function getDetailUrlAttribute()
    {
        return url('news-' . $this->slug);
    }

    public function geCategorylink()
    {
        return route('news.category.index', ['slug' => $this->slug]);
    }

    public function cat()
    {
        return $this->belongsTo('Modules\News\Models\NewsCategory');
    }

    public static function getAll()
    {
        return self::with('cat')->get();
    }

    public function getDetailUrl($locale = false)
    {
        return url(app_get_locale(false, false, '/') . config('news.news_route_prefix') . "/" . $this->slug);
    }

    public function getCategory()
    {
        $catename = $this->belongsTo("Modules\News\Models\NewsCategory", "cat_id", "id");
        return $catename;
    }

    public function getTags()
    {
        $tags = NewsTag::where('news_id', $this->id)->get();
        $tag_ids = [];
        if (!empty($tags)) {
            foreach ($tags as $key => $value) {
                $tag_ids[] = $value->tag_id;
            }
        }
        return Tag::whereIn('id', $tag_ids)->with('translations')->get();
    }

    public static function searchForMenu($q = false)
    {
        $query = static::select('id', 'title as name');
        if (strlen($q)) {

            $query->where('title', 'like', "%" . $q . "%");
        }
        $a = $query->limit(10)->get();
        return $a;
    }

    public function saveTag($tags_name, $tag_ids)
    {

        if (empty($tag_ids))
            $tag_ids = [];
        $tag_ids = array_merge(Tag::saveTagByName($tags_name), $tag_ids);
        $tag_ids = array_filter(array_unique($tag_ids));
        // Delete unused
        NewsTag::whereNotIn('tag_id', $tag_ids)->where('news_id', $this->id)->delete();
        //Add
        NewsTag::addTag($tag_ids, $this->id);
    }

    static public function getSeoMetaForPageList()
    {
        $meta['seo_title'] = setting_item_with_lang("news_page_list_seo_title", false, null) ?? setting_item_with_lang("news_page_list_title", false, null) ?? __("News");
        $meta['seo_desc'] = setting_item_with_lang("news_page_list_seo_desc");
        $meta['seo_image'] = setting_item("news_page_list_seo_image", null) ?? setting_item("news_page_list_banner", null);
        $meta['seo_share'] = setting_item_with_lang("news_page_list_seo_share");
        $meta['full_url'] = url(config('news.news_route_prefix'));
        return $meta;
    }

    public function getEditUrl()
    {
        $lang = $this->lang ?? setting_item("site_locale");
        return route('news.admin.edit', ['id' => $this->id, "lang" => $lang]);
    }

    public function dataForApi($forSingle = false)
    {
        $translation = $this->translateOrOrigin(app()->getLocale());
        $data = [
            'id' => $this->id,
            'slug' => $this->slug,
            'title' => $translation->title,
            'content' => $translation->content,
            'image_id' => $this->image_id,
            'image_url' => get_file_url($this->image_id, 'full'),
            'banner_image_id' => $this->banner_image_id,
            'banner_image_url' => get_file_url($this->banner_image_id, 'full'),
            'category' => NewsCategory::selectRaw("id,name,slug")->find($this->cat_id) ?? null,
            'created_at' => display_date($this->created_at),
            'author' => [
                'display_name' => $this->getAuthor->getDisplayName(),
                'avatar_url' => $this->getAuthor->getAvatarUrl()
            ],
            'url' => $this->getDetailUrl()
        ];
        return $data;
    }

    public function getReviewEnable()
    {
        return setting_item("news_enable_review", 0);
    }

    public function getReviewApproved()
    {
        return setting_item("news_review_approved", 0);
    }

    public function check_enable_review_after_booking()
    {
        $option = setting_item("news_enable_review_after_booking", 0);
        if ($option) {
            $number_review = $this->reviewClass::countReviewByServiceID($this->id, Auth::id()) ?? 0;
            $number_booking = $this->bookingClass::countBookingByServiceID($this->id, Auth::id()) ?? 0;
            if ($number_review >= $number_booking) {
                return false;
            }
        }
        return true;
    }
    public function check_allow_review_after_making_completed_booking()
    {
        $options = setting_item("news_allow_review_after_making_completed_booking", false);
        if (!empty($options)) {
            $status = json_decode($options);
            $booking = $this->bookingClass::select("status")
                ->where("object_id", $this->id)
                ->where("object_model", $this->type)
                ->where("customer_id", Auth::id())
                ->orderBy("id", "desc")
                ->first();
            $booking_status = $booking->status ?? false;
            if (!in_array($booking_status, $status)) {
                return false;
            }
        }
        return true;
    }
    public function update_service_rate()
    {
        $rateData = $this->reviewClass::selectRaw("AVG(rate_number) as rate_total")->where('object_id', $this->id)->where('object_model', $this->type)->where("status", "approved")->first();
        $rate_number = number_format($rateData->rate_total ?? 0, 1);
        $this->review_score = $rate_number;
        $this->save();
    }
    public static function getReviewStats()
    {
        $reviewStats = [];
        if (!empty($list = setting_item("news_review_stats", []))) {
            $list = json_decode($list, true);
            foreach ($list as $item) {
                $reviewStats[] = $item['title'];
            }
        }
        return $reviewStats;
    }
    public function getNumberReviewsInService($status = false)
    {
        return $this->reviewClass::countReviewByServiceID($this->id, false, $status, $this->type) ?? 0;
    }
    public static function getModelName()
    {
        return __("News");
    }
    public static function isEnable()
    {
        return true;
    }
}
