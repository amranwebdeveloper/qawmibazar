<div class="terms_condition_widget">
    <h4 class="title">{{ $item->title }}</h4>
    <div class="widget_list">
        {{ $item->content }}
    </div>
</div>