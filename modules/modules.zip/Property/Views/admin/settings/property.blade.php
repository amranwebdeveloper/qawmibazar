<div class="row">
    <div class="col-sm-4">
        <h3 class="form-group-title">{{ __('Page Search') }}</h3>
        <p class="form-group-desc">{{ __('Config page search of your website') }}</p>
    </div>
    <div class="col-sm-8">
        <div class="panel">
            <div class="panel-title"><strong>{{ __('General Options') }}</strong></div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="">{{ __('Title Page') }}</label>
                    <div class="form-controls">
                        <input type="text" name="property_page_search_title"
                            value="{{ setting_item_with_lang('property_page_search_title', request()->query('lang')) }}"
                            class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label class="">{{ __('Paragraph List Page') }}</label>
                    <div class="form-controls">
                        <textarea name="property_page_search_paragraph" class="form-control">{{ setting_item_with_lang('property_page_search_paragraph', request()->query('lang')) }}</textarea>

                    </div>
                </div>
                <div class="form-group">
                    <label class="">{{ __('Footer Text List Page') }}</label>
                    <div class="form-controls">
                        <textarea name="property_page_search_footer_text" class="form-control">{{ setting_item_with_lang('property_page_search_footer_text', request()->query('lang')) }}</textarea>
                    </div>
                </div>
                @if (is_default_lang())
                    <div class="form-group form-group-image">
                        <label class="control-label">{{ __('Background Image') }}</label>
                        {!! \Modules\Media\Helpers\FileHelper::fieldUpload(
                            'property_page_search_backgraound',
                            $settings['property_page_search_backgraound'] ?? '',
                        ) !!}
                    </div>
                @endif
                @if (is_default_lang())
                    <div class="form-group">
                        <label class="">{{ __('Page list properties layout') }}</label>
                        <div class="form-controls">
                            <select name="property_page_search_layout" class="form-control">
                                <option
                                    {{ setting_item('property_page_search_layout') == 'v1' ? 'selected="selected"' : '' }}
                                    value="v1">{{ __('V1') }}</option>
                                <option
                                    {{ setting_item('property_page_search_layout') == 'map1' ? 'selected="selected"' : '' }}
                                    value="map1">{{ __('Map V1') }}</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="">{{ __('Page single Business layout') }}</label>
                        <div class="form-controls">
                            <select name="property_page_single_layout" class="form-control">
                                <option
                                    {{ setting_item('property_page_single_layout') == 1 ? 'selected="selected"' : '' }}
                                    value="1">{{ __('V1') }}</option>
                            </select>
                        </div>
                    </div>
                @endif
            </div>
        </div>
        @include('Property::admin.settings.form-search')
        @include('Property::admin.settings.form-search-sidebar')
        @include('Property::admin.settings.map-search')
        <div class="panel">
            <div class="panel-title"><strong>{{ __('SEO Options') }}</strong></div>
            <div class="panel-body">
                <div class="form-group">
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#seo_1">{{ __('General Options') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#seo_2">{{ __('Share Facebook') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#seo_3">{{ __('Share Twitter') }}</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="seo_1">
                            <div class="form-group">
                                <label class="control-label">{{ __('Seo Title') }}</label>
                                <input type="text" name="property_page_list_seo_title" class="form-control"
                                    placeholder="{{ __('Enter title...') }}"
                                    value="{{ setting_item_with_lang('property_page_list_seo_title', request()->query('lang')) }}">
                            </div>
                            <div class="form-group">
                                <label class="control-label">{{ __('Seo Description') }}</label>
                                <input type="text" name="property_page_list_seo_desc" class="form-control"
                                    placeholder="{{ __('Enter description...') }}"
                                    value="{{ setting_item_with_lang('property_page_list_seo_desc', request()->query('lang')) }}">
                            </div>
                            <div class="form-group">
                                <label class="control-label">{{ __('Seo Header') }}</label>

                                <textarea name="property_page_list_seo_header" class="form-control" placeholder="{{ __('Enter description...') }}">
                            {{ setting_item_with_lang('property_page_list_seo_header', request()->query('lang')) }}
                            </textarea>
                            </div>
                            @if (is_default_lang())
                                <div class="form-group form-group-image">
                                    <label class="control-label">{{ __('Featured Image') }}</label>
                                    {!! \Modules\Media\Helpers\FileHelper::fieldUpload(
                                        'property_page_list_seo_image',
                                        $settings['property_page_list_seo_image'] ?? '',
                                    ) !!}
                                </div>
                            @endif
                        </div>
                        @php
                            $seo_share = json_decode(setting_item_with_lang('property_page_list_seo_desc', request()->query('lang'), '[]'), true);
                        @endphp
                        <div class="tab-pane" id="seo_2">
                            <div class="form-group">
                                <label class="control-label">{{ __('Facebook Title') }}</label>
                                <input type="text" name="property_page_list_seo_share[facebook][title]"
                                    class="form-control" placeholder="{{ __('Enter title...') }}"
                                    value="{{ $seo_share['facebook']['title'] ?? '' }}">
                            </div>
                            <div class="form-group">
                                <label class="control-label">{{ __('Facebook Description') }}</label>
                                <input type="text" name="property_page_list_seo_share[facebook][desc]"
                                    class="form-control" placeholder="{{ __('Enter description...') }}"
                                    value="{{ $seo_share['facebook']['desc'] ?? '' }}">
                            </div>
                            @if (is_default_lang())
                                <div class="form-group form-group-image">
                                    <label class="control-label">{{ __('Facebook Image') }}</label>
                                    {!! \Modules\Media\Helpers\FileHelper::fieldUpload(
                                        'property_page_list_seo_share[facebook][image]',
                                        $seo_share['facebook']['image'] ?? '',
                                    ) !!}
                                </div>
                            @endif
                        </div>
                        <div class="tab-pane" id="seo_3">
                            <div class="form-group">
                                <label class="control-label">{{ __('Twitter Title') }}</label>
                                <input type="text" name="property_page_list_seo_share[twitter][title]"
                                    class="form-control" placeholder="{{ __('Enter title...') }}"
                                    value="{{ $seo_share['twitter']['title'] ?? '' }}">
                            </div>
                            <div class="form-group">
                                <label class="control-label">{{ __('Twitter Description') }}</label>
                                <input type="text" name="property_page_list_seo_share[twitter][desc]"
                                    class="form-control" placeholder="{{ __('Enter description...') }}"
                                    value="{{ $seo_share['twitter']['title'] ?? '' }}">
                            </div>
                            @if (is_default_lang())
                                <div class="form-group form-group-image">
                                    <label class="control-label">{{ __('Twitter Image') }}</label>
                                    {!! \Modules\Media\Helpers\FileHelper::fieldUpload(
                                        'property_page_list_seo_share[twitter][image]',
                                        $seo_share['twitter']['image'] ?? '',
                                    ) !!}
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@if (is_default_lang())
    <hr>
    <div class="row">
        <div class="col-sm-4">
            <h3 class="form-group-title">{{ __('Review Options') }}</h3>
            <p class="form-group-desc">{{ __('Config review for Business') }}</p>
        </div>
        <div class="col-sm-8">
            <div class="panel">
                <div class="panel-body">
                    <div class="form-group">
                        <label class="">{{ __('Enable review system for Business?') }}</label>
                        <div class="form-controls">
                            <label><input type="checkbox" name="property_enable_review" value="1"
                                    @if (!empty($settings['property_enable_review'])) checked @endif />
                                {{ __('Yes, please enable it') }} </label>
                            <br>
                            <small
                                class="form-text text-muted">{{ __('Turn on the mode for reviewing Business') }}</small>
                        </div>
                    </div>
                    <div class="form-group" data-condition="property_enable_review:is(1)">
                        <label class="">{{ __('Review must be approval by admin') }}</label>
                        <div class="form-controls">
                            <label><input type="checkbox" name="property_review_approved" value="1"
                                    @if (!empty($settings['property_review_approved'])) checked @endif /> {{ __('Yes please') }}
                            </label>
                            <br>
                            <small
                                class="form-text text-muted">{{ __('ON: Review must be approved by admin - OFF: Review is automatically approved') }}</small>
                        </div>
                    </div>
                    <div class="form-group" data-condition="property_enable_review:is(1)">
                        <label class="">{{ __('Review number per page') }}</label>
                        <div class="form-controls">
                            <input type="number" class="form-control" name="property_review_number_per_page"
                                value="{{ $settings['property_review_number_per_page'] ?? 5 }}" />
                            <small class="form-text text-muted">{{ __('Break comments into pages') }}</small>
                        </div>
                    </div>
                    <div class="form-group" data-condition="property_enable_review:is(1)">
                        <label class="">{{ __('Review criteria') }}</label>
                        <div class="form-controls">
                            <div class="form-group-item">
                                <div class="g-items-header">
                                    <div class="row">
                                        <div class="col-md-5">{{ __('Title') }}</div>
                                        <div class="col-md-1"></div>
                                    </div>
                                </div>
                                <div class="g-items">
                                    <?php
                                    if(!empty($settings['property_review_stats'])){
                                    $property_review_stats = json_decode($settings['property_review_stats']);
                                    ?>
                                    @foreach ($property_review_stats as $key => $item)
                                        <div class="item" data-number="{{ $key }}">
                                            <div class="row">
                                                <div class="col-md-11">
                                                    <input type="text"
                                                        name="property_review_stats[{{ $key }}][title]"
                                                        class="form-control" value="{{ $item->title }}"
                                                        placeholder="{{ __('Eg: Service') }}">
                                                </div>
                                                <div class="col-md-1">
                                                    <span class="btn btn-danger btn-sm btn-remove-item"><i
                                                            class="fa fa-trash"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                    <?php } ?>
                                </div>
                                <div class="text-right">
                                    <span class="btn btn-info btn-sm btn-add-item"><i
                                            class="icon ion-ios-add-circle-outline"></i> {{ __('Add item') }}</span>
                                </div>
                                <div class="g-more hide">
                                    <div class="item" data-number="__number__">
                                        <div class="row">
                                            <div class="col-md-11">
                                                <input type="text"
                                                    __name__="property_review_stats[__number__][title]"
                                                    class="form-control" value=""
                                                    placeholder="{{ __('Eg: Service') }}">
                                            </div>
                                            <div class="col-md-1">
                                                <span class="btn btn-danger btn-sm btn-remove-item"><i
                                                        class="fa fa-trash"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endif
@if (is_default_lang())
    <hr>
    <div class="row">
        <div class="col-sm-4">
            <h3 class="form-group-title">{{ __('Review Options for Store') }}</h3>
            <p class="form-group-desc">{{ __('Config review for Store') }}</p>
        </div>
        <div class="col-sm-8">
            <div class="panel">
                <div class="panel-body">
                    <div class="form-group">
                        <label class="">{{ __('Enable review system for Business?') }}</label>
                        <div class="form-controls">
                            <label><input type="checkbox" name="dokan_enable_review" value="1"
                                    @if (!empty($settings['dokan_enable_review'])) checked @endif />
                                {{ __('Yes, please enable it') }} </label>
                            <br>
                            <small
                                class="form-text text-muted">{{ __('Turn on the mode for reviewing Business') }}</small>
                        </div>
                    </div>
                    <div class="form-group" data-condition="dokan_enable_review:is(1)">
                        <label class="">{{ __('Review must be approval by admin') }}</label>
                        <div class="form-controls">
                            <label><input type="checkbox" name="dokan_review_approved" value="1"
                                    @if (!empty($settings['dokan_review_approved'])) checked @endif /> {{ __('Yes please') }}
                            </label>
                            <br>
                            <small
                                class="form-text text-muted">{{ __('ON: Review must be approved by admin - OFF: Review is automatically approved') }}</small>
                        </div>
                    </div>
                    <div class="form-group" data-condition="dokan_enable_review:is(1)">
                        <label class="">{{ __('Review number per page') }}</label>
                        <div class="form-controls">
                            <input type="number" class="form-control" name="dokan_review_number_per_page"
                                value="{{ $settings['dokan_review_number_per_page'] ?? 5 }}" />
                            <small class="form-text text-muted">{{ __('Break comments into pages') }}</small>
                        </div>
                    </div>
                    <div class="form-group" data-condition="dokan_enable_review:is(1)">
                        <label class="">{{ __('Review criteria') }}</label>
                        <div class="form-controls">
                            <div class="form-group-item">
                                <div class="g-items-header">
                                    <div class="row">
                                        <div class="col-md-5">{{ __('Title') }}</div>
                                        <div class="col-md-1"></div>
                                    </div>
                                </div>
                                <div class="g-items">
                                    <?php
                                    if(!empty($settings['dokan_review_stats'])){
                                    $dokan_review_stats = json_decode($settings['dokan_review_stats']);
                                    ?>
                                    @foreach ($dokan_review_stats as $key => $item)
                                        <div class="item" data-number="{{ $key }}">
                                            <div class="row">
                                                <div class="col-md-11">
                                                    <input type="text"
                                                        name="dokan_review_stats[{{ $key }}][title]"
                                                        class="form-control" value="{{ $item->title }}"
                                                        placeholder="{{ __('Eg: Service') }}">
                                                </div>
                                                <div class="col-md-1">
                                                    <span class="btn btn-danger btn-sm btn-remove-item"><i
                                                            class="fa fa-trash"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                    <?php } ?>
                                </div>
                                <div class="text-right">
                                    <span class="btn btn-info btn-sm btn-add-item"><i
                                            class="icon ion-ios-add-circle-outline"></i> {{ __('Add item') }}</span>
                                </div>
                                <div class="g-more hide">
                                    <div class="item" data-number="__number__">
                                        <div class="row">
                                            <div class="col-md-11">
                                                <input type="text" __name__="dokan_review_stats[__number__][title]"
                                                    class="form-control" value=""
                                                    placeholder="{{ __('Eg: Service') }}">
                                            </div>
                                            <div class="col-md-1">
                                                <span class="btn btn-danger btn-sm btn-remove-item"><i
                                                        class="fa fa-trash"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endif
@if (is_default_lang())
    <hr>
    <div class="row">
        <div class="col-sm-4">
            <h3 class="form-group-title">{{ __('Vendor Options') }}</h3>
            <p class="form-group-desc">{{ __('Agent config for Business') }}</p>
        </div>
        <div class="col-sm-8">
            <div class="panel">
                <div class="panel-body">
                    <div class="form-group">
                        <label class="">{{ __('Business created by vendor must be approved by admin') }}</label>
                        <div class="form-controls">
                            <label><input type="checkbox" name="property_vendor_create_service_must_approved_by_admin"
                                    value="1" @if (!empty($settings['property_vendor_create_service_must_approved_by_admin'])) checked @endif />
                                {{ __('Yes please') }} </label>
                            <br>
                            <small
                                class="form-text text-muted">{{ __('ON: When vendor posts a service, it needs to be approved by administrator') }}</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endif
