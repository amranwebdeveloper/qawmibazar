<li>
    <div class="sidebar_range_slider mb30 mt70">
            <input class="range-example-km mb20" value="50" type="text">
            <P class="mt20">Radius around selected destination</P>
    </div>
</li>