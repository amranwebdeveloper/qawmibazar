<div class="col-auto home_form_input mr15 mr0-lg mb20-767">
    <label class="sr-only">{{__('What')}}</label>
    <div class="input-group style1 mb-2 mb0-767">
        <div class="input-group-prepend">
            <div class="input-group-text pl0 pb0-767">{{__('What')}}</div>
        </div>
        <div class="select-wrap style2-dropdown">
            <input type="text" class="form-control refineText formTextbox" id="ServiceName" name="service_name"  value="" placeholder="{{__('What are you looking for')}}">
        </div>
    </div>
</div>
