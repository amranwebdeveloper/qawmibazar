<li class="search_area">
    <div class="form-group">
        <input type="number" class="form-control" placeholder="$title" name="{{$name}}">
    </div>
</li>