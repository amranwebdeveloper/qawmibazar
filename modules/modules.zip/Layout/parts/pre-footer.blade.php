<section class="pre-footer pb40 pt40">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xl-12">
                {!! clean(setting_item_with_lang('footer_text_right')) ?? '' !!}
            </div>
        </div>
    </div>
</section>
