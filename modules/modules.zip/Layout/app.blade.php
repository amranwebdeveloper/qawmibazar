<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="{{ $html_class ?? '' }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="index, follow" />
	<link rel="canonical" href="https://www.qawmibazar.com/" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @php event(new \Modules\Layout\Events\LayoutBeginHead()); @endphp
    @php
        $favicon = setting_item('site_favicon');
    @endphp
    @if ($favicon)
        @php
            $file = (new \Modules\Media\Models\MediaFile())->findById($favicon);
        @endphp
        @if (!empty($file))
            <link rel="icon" type="{{ $file['file_type'] }}" href="{{ asset('uploads/' . $file['file_path']) }}" />
        @else:
            <link rel="icon" type="image/png" href="{{ url('images/favicon.png') }}" />
        @endif
    @endif

    @include('Layout::parts.seo-meta')
    <link href="{{ asset('dist/frontend/guido/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('libs/font-awesome/css/font-awesome.css') }}" rel="stylesheet">
    <link href="{{ asset('libs/ionicons/css/ionicons.min.css') }}" rel="stylesheet">
    <link href="{{ asset('libs/icofont/icofont.min.css') }}" rel="stylesheet">
    <link href="{{ asset('libs/select2/css/select2.min.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/css/notification.css') }}" rel="newest stylesheet">

    <link href="{{ asset('dist/frontend/guido/jquery-ui.min.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/font-awesome-animation.min.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/menu.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/ace-responsive-menu.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/megadropdown.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/bootstrap-select.min.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/simplebar.min.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/progressbar.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/flaticon.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/slider.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/timecounter.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/googlemap.css') }}" rel="stylesheet">

    <link href="{{ asset('dist/frontend/css/app.css?_ver=' . config('app.asset_version')) }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/css/responsive.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/style.css') }}" rel="stylesheet">
    <link href="{{ asset('dist/frontend/guido/responsive.css') }}" rel="stylesheet">


    <link rel="stylesheet" type="text/css" href="{{ asset('libs/daterange/daterangepicker.css') }}">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600&family=Poppins:wght@100;300;400;500;600&display=swap" rel="stylesheet" type='text/css' media='all'>
    {!! \App\Helpers\Assets::css() !!}
    {!! \App\Helpers\Assets::js() !!}
    <script>
        var bookingCore = {
            url: '{{ url(app_get_locale()) }}',
            url_root: '{{ url('') }}',
            booking_decimals: {{ (int) get_current_currency('currency_no_decimal', 2) }},
            thousand_separator: '{{ get_current_currency('currency_thousand') }}',
            decimal_separator: '{{ get_current_currency('currency_decimal') }}',
            currency_position: '{{ get_current_currency('currency_format') }}',
            currency_symbol: '{{ currency_symbol() }}',
            currency_rate: '{{ get_current_currency('rate', 1) }}',
            date_format: '{{ get_moment_date_format() }}',
            map_provider: '{{ setting_item('map_provider') }}',
            map_gmap_key: '{{ setting_item('map_gmap_key') }}',
            routes: {
                login: '{{ route('auth.login') }}',
                register: '{{ route('auth.register') }}',
                checkout: '{{ is_api() ? route('api.booking.doCheckout') : route('booking.doCheckout') }}'
            },
            module: {
                property: '{{ route('property.search') }}',
            },
            currentUser: {{ (int) Auth::id() }},
            isAdmin: {{ is_admin() ? 1 : 0 }},
            rtl: {{ setting_item_with_lang('enable_rtl') ? '1' : '0' }},
            markAsRead: '{{ route('core.notification.markAsRead') }}',
            markAllAsRead: '{{ route('core.notification.markAllAsRead') }}',
            loadNotify: '{{ route('core.notification.loadNotify') }}',
            pusher_api_key: '{{ setting_item('pusher_api_key') }}',
            pusher_cluster: '{{ setting_item('pusher_cluster') }}',
        };
        var i18n = {
            warning: "{{ __('Warning') }}",
            success: "{{ __('Success') }}",
        };
        var daterangepickerLocale = {
            "applyLabel": "{{ __('Apply') }}",
            "cancelLabel": "{{ __('Cancel') }}",
            "fromLabel": "{{ __('From') }}",
            "toLabel": "{{ __('To') }}",
            "customRangeLabel": "{{ __('Custom') }}",
            "weekLabel": "{{ __('W') }}",
            "first_day_of_week": {{ setting_item('site_first_day_of_the_weekin_calendar', '1') }},
            "daysOfWeek": [
                "{{ __('Su') }}",
                "{{ __('Mo') }}",
                "{{ __('Tu') }}",
                "{{ __('We') }}",
                "{{ __('Th') }}",
                "{{ __('Fr') }}",
                "{{ __('Sa') }}"
            ],
            "monthNames": [
                "{{ __('January') }}",
                "{{ __('February') }}",
                "{{ __('March') }}",
                "{{ __('April') }}",
                "{{ __('May') }}",
                "{{ __('June') }}",
                "{{ __('July') }}",
                "{{ __('August') }}",
                "{{ __('September') }}",
                "{{ __('October') }}",
                "{{ __('November') }}",
                "{{ __('December') }}"
            ],
        };
    </script>
    <!-- Styles -->
    @yield('head')
    {{-- Custom Style --}}
    <link href="{{ route('core.style.customCss') }}" rel="stylesheet">
    @if (setting_item_with_lang('enable_rtl'))
        <link href="{{ asset('dist/frontend/css/rtl.css') }}" rel="stylesheet">
    @endif

    {!! setting_item('head_scripts') !!}
    {!! setting_item_with_lang_raw('head_scripts') !!}

    @php event(new \Modules\Layout\Events\LayoutEndHead()); @endphp

</head>

<body
    class="frontend-page {{ !empty($row->header_style) ? 'header-' . $row->header_style : 'header-normal' }} {{ $body_class ?? '' }} @if (setting_item_with_lang('enable_rtl')) is-rtl @endif @if (is_api()) is_api @endif">

    @php
        date_default_timezone_set('Asia/Dhaka');
    @endphp

    <div class="wrapper">
        @if (setting_item('preloader_active') == 1)   <div class="preloader"></div>     @endif
        @php event(new \Modules\Layout\Events\LayoutBeginBody()); @endphp
        {!! setting_item('body_scripts') !!}
        {!! setting_item_with_lang_raw('body_scripts') !!}
        <div class="bc_wrap">
            @if (!is_api())
                @include('Layout::parts.header')
            @endif

            @yield('content')

            @if (!\Request::is('news') && !\Request::is('news/*'))
                @include('Layout::parts.pre-footer')
            @endif

            @include('Layout::parts.footer')
        </div>
        {!! setting_item('footer_scripts') !!}
        {!! setting_item_with_lang_raw('footer_scripts') !!}
        @php event(new \Modules\Layout\Events\LayoutEndBody()); @endphp
    </div>
</body>

</html>
